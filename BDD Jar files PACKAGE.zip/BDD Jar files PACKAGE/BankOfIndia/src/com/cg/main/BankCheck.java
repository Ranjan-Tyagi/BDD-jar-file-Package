package com.cg.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BankCheck {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\BDD\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		  d.get("https://www.bankofindia.co.in/");
	        d.manage().window().maximize();
	        Thread.sleep(4000);
	     //   d.findElement(By.partialLinkText("Personel")).click();
	        d.findElement(By.xpath("/html/body/div/div[2]/div/div/div[2]")).click();
		    Thread.sleep(3000);
	        d.findElement(By.xpath("/html/body/div/div[2]/div/div/div[3]/div/div[2]/div/ul/li[1]/a")).click();
	    Thread.sleep(3000);
	    d.findElement(By.xpath("/html/body/div/table/tbody/tr/td[1]/div/input")).click();
	}
}
