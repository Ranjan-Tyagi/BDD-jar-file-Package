package cap;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\BDD\\KSRTC\\scenario-feature\\abc.Feature"}
		,glue= "KsrtcTicketBoking"
		,plugin={"pretty","html:target/ranjan-report"}
        ,monochrome=true
        ,dryRun=true		
		)

public class Ranjan {

}
