package com.junitRunner;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;

import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions( 
                     features = {"C:\\BDD\\BOI\\scenario-feature1\\x.feature"},
                         glue = "stepdef",
                         monochrome = true,
                         dryRun=true)

public class JunitTest {

}
