package com.cg.main;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Bank_Main {


		@Given("^Open BOI web site$")
		public void open_BOI_web_site() throws Throwable {
			WebDriver d;
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
			d=new ChromeDriver();
			  d.get("https://www.bankofindia.co.in/");
		        d.manage().window().maximize();
		    // Write code here that turns the phrase above into concrete actions
		    throw new PendingException();
		}

		@When("^user inputs \"([^\"]*)\" and \"([^\"]*)\"$")
		public void user_inputs_and(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    throw new PendingException();
		}

		@Then("^Login should be successfull$")
		public void login_should_be_successfull() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    throw new PendingException();
		}
	}

