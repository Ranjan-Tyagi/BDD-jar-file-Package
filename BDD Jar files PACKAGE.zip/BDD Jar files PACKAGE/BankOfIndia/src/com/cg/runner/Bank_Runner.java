package com.cg.runner;



	
	
	import org.junit.runner.RunWith;
	import cucumber.api.CucumberOptions;
	import cucumber.api.junit.Cucumber;
	import org.junit.runner.RunWith;
	import cucumber.api.junit.Cucumber;
	@RunWith(Cucumber.class)
	@CucumberOptions(
					features={"C:\\BDD\\BankOfIndia\\scenario-feature\\bank.Feature"}
					,glue="Bank_Main"
				    ,plugin = {"pretty", "html:target/soumya-report"}
					,monochrome=true
							)
	
	public class Bank_Runner {
	
	
	
}
