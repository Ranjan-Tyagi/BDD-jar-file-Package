package com.cg.java;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

@SuppressWarnings({ "unused", "deprecation" })
public class AddTest {

	@Test
	public void testAdd() {
//		classadd a=new classadd();
//		sumresult=a.sum(3,5);
//		Assert.assertEquals(8, sumresult);
		
		add_number  ad=new add_number();
		int result=ad.add(2,4);
		Assert.assertEquals(6, result);
		
		
		
		//fail("Not yet implemented");
	}

}
