package cap;


import org.openqa.selenium.By;  
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class KsrtcTicketBoking {
	
	WebDriver d;
	
	@Given("^Open ksrtc web site$")
	 public void open_ksrtc_web_site() throws Throwable
	 {
		System.setProperty("webdriver.chrome.driver", "C:\\BDD\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		d=new ChromeDriver();
	   // d.get("https://www.irctc.co.in/nget/train-search");
		d.get("https://www.ksrtc.in");
		
		d.manage().window().maximize();
//		   throw new PendingException();
	 }
	
	 @When("^user input Username \"([^\"]*)\"$")
	  public void user_inputs_Username(String name) throws Throwable
	  {
		  d.findElement(By.linkText("Sign In")).click();
		  d.findElement(By.xpath("//*[@id='userName']")).sendKeys("mah@yahoo.com");
//		   throw new PendingException();
	  }
	 
	 @When("^user input password \"([^\"]*)\"$")
	  public void user_input_password(String password) throws Throwable
	  {
		  d.findElement(By.xpath("//*[@id='password']")).sendKeys("mysore15");
//		  Thread.sleep(5000);
		  d.findElement(By.xpath("//*[@id='submitBtn']")).click();
//	   throw new PendingException();
	  }

	
	 
	 @Then("^Login should be successful$")
	 public void Login_should_be_successful() throws Throwable
	 {
		 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		 if(a)
		 {
			 System.out.println("Login is successful");
		 }
		 else
		 {
			 System.out.println("Login is NOT successful");
		 }
//		   throw new PendingException();
	 }
	 
	

}
