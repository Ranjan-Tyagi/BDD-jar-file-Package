package com.cg.java;

import java.util.Scanner;

@SuppressWarnings("unused")
public class add_number {
//
//	void add()
//	
//	{
//		int sum;
//		Scanner sc=new Scanner(System.in);
//		int x=sc.nextInt();
//		int y=sc.nextInt();
//		sum=x+y;
//		System.out.println("Sum of 2 number is:"+sum);
//	}
	
	int add(int x,int y)
	
	{
		int sum=x+y;
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		add_number  ad=new add_number();
		int result=ad.add(2,4);
		System.out.println("SUM IS:"+result);

		
	}

}
